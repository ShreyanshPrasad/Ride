$(document).ready(function(){

	function checkEmpty(ele){
		if(ele == undefined || ele == null || ele == "")
			return true;
		return false;
	}

	$("#txt1").change(function(){
		if(checkEmpty($("#txt1").val()))
			$("#nameError").css({"display" : "block"});
		else
			$("#nameError").css({"display" : "none"});
	});

	$("#txt1").on('input' , function(){
		if(!$("#txt1").val().match(/^[a-zA-Z\s]+$/)){
			$("#txt1").val($("#txt1").val().replace($("#txt1").val() , $("#txt1").val().substring(0,$("#txt1").val().length-1)));
			$("#nameError").css({"display" : "block"});
		}
		else
			$("#nameError").css({"display" : "none"});
	});

	$("#txt2").change(function(){
		if(checkEmpty($("#txt2").val()))
			$("#userNameError").css({"display" : "block"});
		else
			$("#userNameError").css({"display" : "none"});
	});

	$("#txt4").on('input' , function(){
		if(!$("#txt4").val().match(/^[a-zA-Z0-9w-.+]+@[a-zA-Z.-]+.[a-zA-Z0-9]$/)){
			$("#emailError").css({"display" : "block"});
		}
		else
			$("#emailError").css({"display" : "none"});
	});

	$("#txt4").change(function(){
		if(checkEmpty($("#txt4").val()))
			$("#emailError").css({"display" : "block"});
		else
			$("#emailError").css({"display" : "none"});
	});

	$("#txt5").on('input' , function(){
		if(!$("#txt5").val().match(/^[0-9]$/)){
			$("#emailError").css({"display" : "block"});
		}
		else
			$("#emailError").css({"display" : "none"});
	});

	$("#txt5").change(function(){
		if(checkEmpty($("#txt5").val()))
			$("#emailError").css({"display" : "block"});
		else
			$("#emailError").css({"display" : "none"});
	});


	
	var n;

	$("#ps1").on('input',function(){
		var chkSmall = false;
		var chkCaps = false;
		var chkNum = false;
				n = $("#ps1").val().length;

				for(var i = 0 ; i < n ; i++){
					if($("#ps1").val().charCodeAt(i) >= 97 && $("#ps1").val().charCodeAt(i) <= 122)
						chkSmall = true;
				}
				
				for (var i = 0; i < n; i++) {
					if($("#ps1").val().charCodeAt(i) >= 65 && $("#ps1").val().charCodeAt(i) <= 90)
						chkCaps = true;
				}
				
				for (var i = 0; i < n; i++) {
					if($("#ps1").val().charCodeAt(i) >= 48 && $("#ps1").val().charCodeAt(i) <= 57)
						chkNum = true;
				}
				var pb = document.getElementsByTagName("progress");
				pb[0].setAttribute("value",n);
				if(chkSmall && chkCaps && chkNum && $("#ps1").val().length >=8 && $("#ps1").val().length <=16)
					$("#passwordError").css({"display" : "none"});
				else
					$("#passwordError").css({"display" : "block"});
	});

	$("#ps1").change(function(){
		$("#ps2").val("");
	});

	$("#ps2").on('input',function(){
		if($("#ps2").val() == $("#ps1").val())
			$("#cPasswordError").css({"display" : "none"});
		else
			$("#cPasswordError").css({"display" : "block"});
	});

});