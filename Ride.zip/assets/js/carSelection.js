function vehicleTypeChange(){
	var ele = document.getElementById('selectVehicle');
	var carType = document.getElementById('carType');
	if(ele.value == 'car'){
		carType.style.display = "block";
	}
	else{
		carType.style.display = "none";
	}
}